#Winners and losers of reef flattening: An assessment of coral reef fish species and traits
---

Datasets include density data for 109 fish species included in the analysis, environmental data used for the density analysis, and a trait table which includes the response variables of association with relief and coral cover.

## Description of the data and file structure

SpecAbund.xlsx - data used for the boosted regression tree models for fish species density. Includes all density information 109 species and all environmental variables
SiteEnv.xlsx - environmental data extracted from geospatial layers and matched to fish survey sites. Already merged with the species dataset in SpecAbund.xlsx but included as a smaller file
traits\_combined\_2023.xlsx - trait data and response variables used for the trait analysis. Response variables extracted from boosted regression tree models and traits derived from literature and FishBase

Columns in SpecAbund and SiteEnv:
site: numeric site descriptor matching NOAA Reef Visual Census sites
model: factor used to subset data for two separate models - not used in these analyses
Year: year of RVC fish survey
Month: month of RVC fish survey
Latitude: latitude of RVC fish survey
Longitude: longitude of RVC fish survey
Depth: depth of RVC fish survey averaged for each surveyor
Region: jurisdiction of RVC fish survey. FLA KEYS = Florida Keys; DRY TORT = Dry Tortugas; SEFCRI = Southeast Florida Coral Reef Initiative (Renamed to Coral Ecological Conservation Area)
Coral\_cover: percentage of benthos made up of living hard coral visually estimated by RVC surveyors
Reef\_complexity: maximum hard relief measured by averaging the height of the highest rigid point above the lowest point in 8 segments of the cylinder for RVC surveys
SST: minimum monthly average sea surface temperature in Celcius derived from CoRTAD database from 2012-2016
NPP: net primary productivity derived from remotely sensed chlorophyll-a from the OSU VGPM model
Wave\_exposure: exposure calculated using linear wave theory
Habitat\_type\_classLV0: habitat classification of each site according to the FWC Unified Reef Map level 0
Habitat\_type\_classLV2: habitat classification of each site according to the FWC Uniifed Reef Map level 2
Coral\_area\_UFRTM\_20km: area classified as reef by Unified Reef Map level 0 within 20km of each site
Coral\_area\_UFRTM\_200km: area classified as reef by Unified Reef Map level 0 within 200km of each site
Depth\_Sbracco: remotely sensed depth of survey sites
Deepwater: euclidean distance in meters over water to the 30-meter bathymetric line
FSA: euclidean distance in meters over water to the nearest fish spawning aggregation site
Marina\_slips\_10km: number of marina slips over 45ft within 10km of each site
Marina\_slips\_25km: number of marina slips over 45ft within 25km of each site
Marine\_reserve: protected status of site; whether fishing was allowed or not
Population\_20km: human population living within 20km of reef sites derived from LandScan dataset
Population\_50km: human population living within 50km of reef sites derived from LandScan dataset
Recreational\_fishermen\_50km: number of recreational fishing licenses within 50km of reef sites derived by zip code
Tourist\_fishing: statistics from Johns et al. 2001 and publicly available dataset of hotel units in Florida
Artificial\_reefs\_1km: number of artificial reefs within 1 km
SG\_permits\_50km: number of recreational snapper-grouper fishing permits within 50km
SG\_charter\_permits\_50km: number of commercial snapper-grouper fishing permits within 50km
total\_gravity\_intercept: number of people in population centers within 500km divided by the square of travel time (same as Total\_gravity and this column was not used)
Total\_gravity: number of people in population centers within 500km divided by the square of travel time
Keys\_Division: sub-jurisdictions of Florida Keys including Upper, Middle, Lower Keys and Marquesas; NAs for non Florida Keys sites
FKNMS: Florida Keys National Marine Sanctuary sites; NAs for non Florida Keys sites
DryTortugas: Dry Tortugas sites; NAs for non-Dry Tortugas sites
BNP: Biscayne National Park sites; NAs for non-BNP sites
CoralECA: Coral Ecological Conservation Area sites; NAs for non-ECA sites (also known as SEFCRI)
Nursery\_seagrass: connectivity of reef sites to continuous seagrass patches within 10 km
Nursery\_mangroves: connectivity of reef sites to mangrove stands within 12 km
connectivity: number of larva from upstream modeledto a connectivity matrix; model does not extend to further north reefs and those sites were assigned NAs
Comm\_engagement: metrics of commercial engagement based on landings and permits provided by NOAA
Comm\_reliance: metrics of commercial engagement based on landings and permits relative to size of fishing community provided by NOAA
Rec\_engagement: metrics of recreational engagement based on landings and permits provided by NOAA
Rec\_reliance: metrics of recreational engagement based on landings and permits relative to size of fishing community provided by NOAA
pop\_per\_area\_reef\_20km: human population divided by area of reef within 20km
Commerical\_pounds\_landed: annual number of pounds of fish reported by commercial anglers
Random: random number assigned to each column; not used in final model
impact: fishing impact variable derived in previous project; not used in final model
YEAR: Year of RVC surveys, repeat of earlier column
HABITAT\_CD: habitat code used by NOAA RVC surveys to stratify sites
PCT\_CORALCOVER: percent coral cover, same as Coral\_cover column
REGION: jurisdiction of RVC survey sites, repeat of earlier column
MAX\_HARD\_RELIEF: maximum hard relief; same as Reef\_complexity column

Columns in SpecAbund (not in SiteEnv):
no.divers: number of divers for RVC survey
Remaining variables are individual reef fish species that were present on at least 4% of reef surveys

Columns in traits\_combined\_2023:
Species: full species name with space
Sp: full species name with underscore
Family: family
Genus: genus
Spec: species epithet
MaxLengthTL: maximum total length in cm for South Florida/Caribbean where available
Body\_size\_max: maximum total length in cm overall - contains typos and not used
MaximumLengthSL: maximum standard length in cm for South Florida/Caribbean where available
MaxJuvLength: maximum length of juvenile stages
AspectRatio: aspect ratio of caudal fin measured as the Area^2/Height; derived from FishBase or calculated from photos
AspectRatio\_Q: aspect ratio of caudal fin measured as the Area^2/Height; derived from Quimbayo et al. 2021
Log\_AR: natural log of AspectRatio column
swim\_type: combination of fins used to propel fish
swim\_mode: combination of fins and body movement used to propel fish
body\_shape: categorical variable describing body fineness
Total.length.body.depth.ratio: numerical variable describing body fineness; calculated by total length of fish divided by height at the pectoral fin
presence\_defense: binary variable of whether species has chemical or physical defenses
ComDepthMax: common maximum depth of species
DepthMax: maximum recorded depth of species
Depth\_min: minimum recorded depth
Depth\_range: DepthMax minus Depth\_min
Troph: trophic level of species
Trophic\_level: trophic level of species - contains typos and not used
Diet.x: categorical variable of feeding type; H = Herbivore, C = Carnivore, P = Piscivore, Z = Planktivore - not used
Diet.y: categorical variable of feeding type; om = omnivore, im = invertivore, is = invertivore and omnivore, pk = planktivore, hd = herbivore, fc = piscivore - not used
Noctural: binary variable of whether species is active at night
Diel\_activity: categorical variable of whether species is active during day, night, or both
shoaling: categorical variable of group size; solitary, paired, shoaling (loose aggregation), or schooling - not used
Size\_group: categorical variable of group size; solitary, paired, small group, medium group, large group
Position.in.water.column: common position in water column of species
level\_water: common position in water column - not used
Specialist: binary variable of specialization to reef; 1 = found only on coral reefs
Fished: binary variable of whether species is targeted by anglers; 1 = fished
Spawn: spawning mode of species; PEL = Pelagic, BAL = Balistiform, DEM = Demersal
Spawning: spawning mode of species
Brackish: species found in lower salinity habitats
Multihabitat: species found in habitats other than coral reefs
Rafter: species larvae rafting
Relief: percent contribution of maximum hard relief to overall fish density derived from density models
Coral: percent contribution of coral cover to overall fish density derived from density models
Cryptic: binary variable of whether species are considered cryptic and to be excluded from trait models
random: random variable used to determine significance in trait models
Home\_range: size of home range; mob = mobile, vmob = highly mobile; sed = sedentary

## Sharing/Access information

Data was derived from the following sources:

* Geospatial data was extracted using the protocols described in: Zuercher, R., D. P. Kochan, R. D. Brumbaugh, K. Freeman, R. Layko, and A. R. Harborne. 2023. Identifying correlates of coral-reef fish biomass on Florida’s Coral Reef to assess potential management actions. Aquatic Conservation: Marine and Freshwater Ecosystems 33:246–263.
* Fish density data extracted from NOAA RVC Surveys: https://grunt.sefsc.noaa.gov/rvc\_analysis20/ and reproduced under open data sharing licenses.
* Trait data were extracted from a variety of sources, described in the paper and shared under open data licenses. Sources include FishBase (Froese and Pauly, 2000), Quimbayo, J. P., F. C. Silva, T. C. Mendes, D. S. Ferrari, S. L. Danielski, M. G. Bender, V. Parravicini, M. Kulbicki, and S. R. Floeter. 2021. Life‐history traits, geographical range, and conservation aspects of reef fishes from the Atlantic and Eastern Pacific. Ecology 102.,
    Green, S. J., and I. M. Côté. 2014. Trait-based diet selection: Prey behaviour and morphology predict vulnerability to predation in reef fish communities. Journal of Animal Ecology 83:1451–1460., Bridge, T. C. L., O. J. Luiz, R. R. Coleman, C. N. Kane, and R. K. Kosaki. 2016. Ecological and morphological traits predict depth-generalist fishes on coral reefs. Proceedings of the Royal Society B: Biological Sciences 283:20152332.,